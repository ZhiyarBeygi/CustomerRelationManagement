import { useEffect, useState } from "react";
import { api } from "../api";
import { getUser, isSupportRole } from "../auth";
import "./Comments.css";

function formatDate(value) {
  const date = value ? new Date(value) : null;
  return date && !Number.isNaN(date.getTime()) ? date.toLocaleString("fa-IR") : "نامشخص";
}

export default function Comments({ ticketId, canModerate = false }) {
  const me = getUser();
  const staff = canModerate || isSupportRole(me?.role);
  const [comments, setComments] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [isInternal, setIsInternal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [deletingId, setDeletingId] = useState(null);

  async function load() {
    const list = await api(`/api/Comments/ticket/${ticketId}`);
    const safeList = Array.isArray(list) ? list : [];
    setComments(staff ? safeList : safeList.filter((comment) => !comment.isInternal));
  }

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    api(`/api/Comments/ticket/${ticketId}`)
      .then((list) => {
        if (!active) return;
        const safeList = Array.isArray(list) ? list : [];
        setComments(staff ? safeList : safeList.filter((comment) => !comment.isInternal));
      })
      .catch((err) => { if (active) setError(err.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [ticketId, staff]);

  async function handleAdd(e) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      await api("/api/Comments", {
        method: "POST",
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim(),
          authorId: me.userId,
          ticketId,
          isInternal: staff && isInternal,
        }),
      });
      setTitle("");
      setDescription("");
      setIsInternal(false);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  function startEdit(comment) {
    setError("");
    setEditingId(comment.commentId);
    setEditTitle(comment.title);
    setEditDescription(comment.description);
  }

  async function saveEdit(e) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      await api(`/api/Comments/${editingId}`, {
        method: "PUT",
        body: JSON.stringify({ title: editTitle.trim(), description: editDescription.trim() }),
      });
      setEditingId(null);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function deleteComment(commentId) {
    setError("");
    setDeletingId(commentId);
    try {
      await api(`/api/Comments/${commentId}`, { method: "DELETE" });
      setComments((current) => current.filter((comment) => comment.commentId !== commentId));
    } catch (err) {
      setError(err.message);
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <section className="comments" aria-label="دیدگاه‌های تیکت" dir="rtl">
      <h4>گفت‌وگو درباره تیکت</h4>
      {error && <p className="error" role="alert">{error}</p>}
      {loading && <p className="muted">در حال بارگذاری دیدگاه‌ها…</p>}
      {!loading && comments.length === 0 && <p className="muted">هنوز دیدگاهی ثبت نشده است.</p>}

      {comments.map((comment) => {
        const mine = comment.authorId === me?.userId;
        const canEdit = mine || staff;
        if (editingId === comment.commentId) {
          return (
            <form className="comment mine" key={comment.commentId} onSubmit={saveEdit}>
              <label>عنوان دیدگاه
                <input aria-label="عنوان دیدگاه" value={editTitle} onChange={(e) => setEditTitle(e.target.value)} maxLength={100} required />
              </label>
              <label>متن دیدگاه
                <textarea aria-label="متن دیدگاه" value={editDescription} onChange={(e) => setEditDescription(e.target.value)} maxLength={500} required />
              </label>
              <div className="comment-actions">
                <button type="submit" disabled={submitting}>ذخیره تغییرات</button>
                <button type="button" className="secondary" onClick={() => setEditingId(null)}>انصراف</button>
              </div>
            </form>
          );
        }

        return (
          <article className={`comment${mine ? " mine" : ""}${comment.isInternal ? " internal" : ""}`} key={comment.commentId}>
            <strong>{comment.title}</strong>
            <p>{comment.description}</p>
            <small>
              {mine ? "شما" : comment.authorUsername || `کاربر شماره ${comment.authorId}`} · {formatDate(comment.createdAt)}
              {comment.isInternal ? " · یادداشت داخلی" : ""}
            </small>
            <div className="comment-actions">
              {canEdit && <button type="button" className="secondary" onClick={() => startEdit(comment)}>ویرایش</button>}
              {canEdit && <button type="button" className="danger" disabled={deletingId === comment.commentId} onClick={() => deleteComment(comment.commentId)}>{deletingId === comment.commentId ? "در حال حذف…" : "حذف"}</button>}
            </div>
          </article>
        );
      })}

      <form onSubmit={handleAdd}>
        <label>عنوان دیدگاه
          <input aria-label="عنوان دیدگاه" placeholder="عنوان" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={100} required />
        </label>
        <label>متن دیدگاه
          <textarea aria-label="متن دیدگاه" placeholder="پیام خود را بنویسید…" value={description} onChange={(e) => setDescription(e.target.value)} maxLength={500} required />
        </label>
        {staff && (
          <label className="checkbox-label">
            <input type="checkbox" checked={isInternal} onChange={(e) => setIsInternal(e.target.checked)} />
            یادداشت داخلی (برای کاربران عادی نمایش داده نشود)
          </label>
        )}
        <button type="submit" disabled={submitting}>{submitting ? "در حال ثبت…" : "ثبت دیدگاه"}</button>
      </form>
    </section>
  );
}
