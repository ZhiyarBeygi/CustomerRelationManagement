function normalizeUser(user) {
  if (!user) return null;

  return {
    ...user,
    userId: user.userId ?? user.user_id ?? user.id ?? null,
    username: user.username ?? user.userName ?? "",
    roleId: user.roleId ?? user.role_id ?? null,
    role: user.role ?? user.roleName ?? "",
    departmentId: user.departmentId ?? user.department_id ?? null,
    department: user.department ?? user.departmentName ?? "",
  };
}

export function saveAuth(data) {
  const user = normalizeUser(data?.user ?? data);
  if (!user) throw new Error("اطلاعات کاربر در پاسخ ورود وجود ندارد.");

  localStorage.setItem("user", JSON.stringify(user));
  if (data?.token) localStorage.setItem("token", data.token);
  else localStorage.removeItem("token");
}

export const getToken = () => localStorage.getItem("token");

export function getUser() {
  try {
    return normalizeUser(JSON.parse(localStorage.getItem("user") || "null"));
  } catch {
    return null;
  }
}

function normalizedRole(role) {
  return String(role ?? "").trim().toLowerCase();
}

export function isAdminRole(role) {
  return normalizedRole(role) === "admin" || normalizedRole(role) === "administrator";
}

export function isExpertRole(role) {
  return ["expert", "support expert", "supportexpert", "technician", "agent"].includes(normalizedRole(role));
}

export function isSupportRole(role) {
  return isAdminRole(role) || isExpertRole(role);
}

export function roleLabel(role) {
  if (isAdminRole(role)) return "مدیر سیستم";
  if (isExpertRole(role)) return "کارشناس";
  if (["user", "standard user", "normal user"].includes(normalizedRole(role))) return "کاربر";
  if (["support expert", "supportexpert", "technician", "agent"].includes(normalizedRole(role))) return "کارشناس";
  return role || "کاربر";
}

export function homePath(user) {
  if (!user) return "/login";
  return isSupportRole(user.role) ? "/admin" : "/tickets";
}

export function clearAuth() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
}
